export const template1Selector = (state) => state.template1
