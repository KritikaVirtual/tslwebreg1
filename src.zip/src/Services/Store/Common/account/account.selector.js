export const userListById = (state) => state.userListById.showList;
export const paymentDetailsSelector = (state) => state.paymentDetails.paymentDetails;

export const mainClient = (state) => state.userListById.mainClientresponse;