export const pageDesignSelector = (state) => state.pageDesign;
export const regTypesPageDesignSelector = (state) => state.pageDesign.regTypesPageDesign;
export const regTypesByIDSelector = (state) => state.regTypesById;
export const regCategoriesPageDesignSelector=(state) => state.regCategoriesPageDesign;
// export const regScodeSelector=(state) => state.regScode;
