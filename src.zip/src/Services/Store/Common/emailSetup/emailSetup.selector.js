export const emailSetupSelector = (state) => state.emailSetup;
