export const template21Selector = (state) => state.template21
