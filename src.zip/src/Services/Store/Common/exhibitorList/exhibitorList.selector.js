export const exhibitorListSelector = (state) => state.exhibitorList;

export const exhibitorListByIdSelector = (state) => state.exhibitorListById;