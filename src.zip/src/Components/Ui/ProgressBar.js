import React, { useEffect, useState } from "react";

export default function ProgressBar () {
 
  return (
    <>
      <div class="">    
        <div class="progress progress-striped">
            <div class="progress-bar">
            </div>                       
        </div> 
        </div>

        {/* <div class="container">    
        <div class="progress2 progress-moved">
            <div class="progress-bar2" >
            </div>                       
        </div> 
        </div>

        <div class="container">    
        <div class="progress progress-infinite">
            <div class="progress-bar3" >
            </div>                       
        </div> 
        </div> */}
    </>
  );
}
